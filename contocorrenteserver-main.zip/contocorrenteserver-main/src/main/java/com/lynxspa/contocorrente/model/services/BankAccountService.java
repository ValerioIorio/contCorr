package com.lynxspa.contocorrente.model.services;

import com.lynxspa.contocorrente.model.dao.BankAccountDao;
import com.lynxspa.contocorrente.model.dao.UserDao;
import com.lynxspa.contocorrente.model.entities.BankAccount;
import com.lynxspa.contocorrente.model.entities.User;
import com.lynxspa.contocorrente.model.exceptions.WithdrawalException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

@Service
public class BankAccountService {

    @Autowired
    BankAccountDao bankAccountDao;
    @Autowired
    UserDao userDao;





    public String deposit(double depositSum, User user, long bankAccountId)
    {
        BankAccount bankAccount = userDao.getAccount(user, bankAccountId);


        if (depositSum<=0)
            return "invalid deposit sum";
        else
        {
            bankAccount.setBalance( bankAccount.getBalance()+depositSum);
            bankAccountDao.addDepositTransaction(depositSum, bankAccount, user);
            return "done, actual balance: "+  bankAccount.getBalance();
        }



    }
    public String withdraw(double withdrawSum, User user, long bankAccountId)
    {
        BankAccount bankAccount = userDao.getAccount(user, bankAccountId);
        try
        {
            if( bankAccount.getBalance()<withdrawSum)
                throw new WithdrawalException("you don't have enough money");
        }
        catch(WithdrawalException e)
        {
            return e.getMessage();
        }

        bankAccount.setBalance(bankAccount.getBalance()-withdrawSum);
        bankAccountDao.addWhithdrawTransaction(user, withdrawSum, bankAccount);


        return "done, actual balance: "+  bankAccount.getBalance();


    }
    public String calcolateInterests(long bankAccountId, User user)
    {
        BankAccount bankAccount = userDao.getAccount(user, bankAccountId);

        int res=0;
        int interest= 0;

        if ( bankAccount.getBalance()>100 &&  bankAccount.getBalance()<1000)
            res+= 2;
        if ( bankAccount.getBalance()>1000)
            res+= 4;

        interest +=  bankAccount.getBalance()*100/res;

        return "you have an interests of "+ res + "%, total: " + interest;

    }
    public String displayTransaction(long bankAccountId, User user)
    {
        BankAccount bankAccount = userDao.getAccount(user, bankAccountId);
        String res="";
        for(String transaction : bankAccount.getTransactions())
            res += transaction + "\n";


        return res;
    }








}



