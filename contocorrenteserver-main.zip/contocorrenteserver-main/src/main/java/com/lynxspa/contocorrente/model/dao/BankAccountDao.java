package com.lynxspa.contocorrente.model.dao;

import com.lynxspa.contocorrente.model.entities.BankAccount;
import com.lynxspa.contocorrente.model.entities.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

    @Component
    public class BankAccountDao
    {

        @Autowired
        UserDao userDao;







        public void addDepositTransaction(double depositSum, BankAccount bankAccount, User user)
        {
            bankAccount.getTransactions().add("deposit of " + LocalDate.now() +" --  + " + depositSum);
            bankAccount.setBalance(bankAccount.getBalance()+depositSum);
            //tecnicamente ora la lista di stringhe dovrebbe essere aggiornata sul database
            userDao.update(user, bankAccount.getId(), bankAccount);
        }

        public void addWhithdrawTransaction(User user, double withdrawSum, BankAccount bankAccount)
        {
            bankAccount.getTransactions().add("withdraw of " + LocalDate.now() +" --  + " + withdrawSum);
            bankAccount.setBalance(bankAccount.getBalance()-withdrawSum);
            //tecnicamente ora la lista di stringhe dovrebbe essere aggiornata sul database
            userDao.update(user, bankAccount.getId(), bankAccount);
        }





    }
