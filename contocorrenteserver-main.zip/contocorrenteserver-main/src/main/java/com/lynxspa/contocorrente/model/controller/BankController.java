package com.lynxspa.contocorrente.model.controller;

import com.lynxspa.contocorrente.ContocorrenteApplication;
import com.lynxspa.contocorrente.model.dao.BankDao;
import com.lynxspa.contocorrente.model.entities.BankAccount;
import com.lynxspa.contocorrente.model.entities.User;
import com.lynxspa.contocorrente.model.services.BankAccountService;
import com.lynxspa.contocorrente.model.services.BankService;
import com.lynxspa.contocorrente.model.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Scanner;


@Component
public class BankController  {


    Scanner k = new Scanner(System.in);
    String username;
    String password;
    User loggedUser;

    BankAccount selectedBankAccount;

    String cmd;

    @Autowired
    BankService bankService;
    @Autowired
    UserService userService;
    @Autowired
    BankAccountService bankAccountService;
    @Autowired
    BankDao bankDao;




   public void _loginMenu()
   {

    bankDao.createMockUser();
    System.out.println(bankDao.toString());

       do
       {

           System.out.println("1 to login - 2 to exit");
           cmd = k.nextLine();
           String res;

           switch(cmd)
           {
               case "1":
                   res = _login();

                   break;

               case "2":
                   res = "See you.";
                   break;

               default :
                   res= "invalid command";
           }
           System.out.println(res);
       }while(!cmd.equalsIgnoreCase("2"));
   }


    public String _login(){

            System.out.println("username:");
            username=k.nextLine();

            System.out.println("password");
            password=k.nextLine();

            loggedUser = bankService.login(username, password);

            if (loggedUser==null)
            {
                return "username or password not valid";
            }

            System.out.println("welcome " + loggedUser.getUsername());

            cmd = k.nextLine();

            do
            {
                System.out.println(homeboard());
                String res;

                switch(cmd)
                {
                    case "1":
                        res = _openAccount();
                        break;

                    case "2":
                        res = _viewAccounts();
                        break;

                    case "3":
                        res = _logout();
                        break;

                    case "4":
                        res = _createBankAccount();
                        break;

                    case "5":
                        res = _createSavingsBankAccount();
                        break;

                    case "6":
                        res = _deleteBankAccount();
                        break;

                    default :
                        res= "invalid command";
                }
                System.out.println(res);
            }while(!cmd.equalsIgnoreCase("3"));
           return "";
        }

    public String homeboard()
    {
        return  "hi " + loggedUser.getUsername() +
                ", Select an option:\n" +
                "1-Open Account\n" +
                "2-View Accounts\n" +
                "3-Logout\n" +
                "4-Create new BankAccount\n" +
                "5-Delete BankAccount\n";
    }

    public String bankAccountBoard()
    {
        return "Select an option:\n"      +
                "1-View Balance\n"        +
                "2-Deposit\n"             +
                "3-Withdraw\n"            +
                "4-Calculate interests\n" +
                "5-View transactions\n"   +
                "6-return to user bord"                  ;
    }







    public String _openAccount()
    {
        System.out.println("Insert bank account id");
        long id= k.nextLong();
        selectedBankAccount = userService.getBankAccount(id, loggedUser);

        cmd = k.nextLine();
        String res;
        do
        {
            System.out.println(
                             "bank account: " +
                             selectedBankAccount.getName() +
                            "\n\n"+bankAccountBoard());


            switch(cmd)
            {
                case "1":
                    res = _viewBalance();
                    break;

                case "2":
                    res = _deposit();
                    break;

                case "3":
                    res = _withdraw();
                    break;

                case "4":
                    res = _calculateInterests();
                    break;

                case "5":
                    res = _viewTransactions();
                    break;

                case "6":
                    res = "";
                    break;

                default :
                    res= "invalid command";
            }
            System.out.println(res);
        }while(!cmd.equalsIgnoreCase("6"));

        return "";
    }


    public String _viewBalance()
    {
        return bankAccountService.displayTransaction(selectedBankAccount.getId(), loggedUser);
    }

    public String  _deposit(){
        System.out.println("how much do ou want to deposit?");
        double deposit = k.nextDouble();
        return bankAccountService.deposit(deposit, loggedUser, selectedBankAccount.getId());

    }

    public String _withdraw()
    {
        System.out.println("how much do ou want to withdraw?");
        double withdraw = k.nextDouble();
        return bankAccountService.withdraw(withdraw, loggedUser, selectedBankAccount.getId());
    }

    public String _calculateInterests(){
        return bankAccountService.calcolateInterests(selectedBankAccount.getId(), loggedUser);
    }

    public String _viewTransactions(){
        return  bankAccountService.displayTransaction(selectedBankAccount.getId(), loggedUser);
    }










    public String _viewAccounts()
    {
        return userService.showUserSheet(loggedUser.getId());
    }

    public String _logout()
    {
        if (!bankService.logout(loggedUser))
            return "error";

        loggedUser = null;

        return "";
    }

    public String _createBankAccount()
    {
        System.out.println("insert new account's name");
        String name= k.nextLine();
        if (userService.createNormalAccount(loggedUser, name))
            return "you have a new bank account!";

        return "invalid name";


    }


    public String _createSavingsBankAccount()
    {
        System.out.println("insert new savings account's name");
        String name= k.nextLine();
        System.out.println("declare how much money you have rn");
        double balance= k.nextDouble();


        if (userService.createSavingsAccount(loggedUser, name, balance))
            return "you have a new bank account!";

        return "invalid data";
    }

    public String _deleteBankAccount()
    {
        System.out.println("insert the id of the account that you want to delete");
        long id = k.nextLong();
        userService.deleteAccount(loggedUser, id);
        return  "done";
    }



























}

