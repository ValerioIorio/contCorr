package com.lynxspa.contocorrente.model.exceptions;

public class WithdrawalException extends Exception
{
    public WithdrawalException(String message)
    {
        super(message);
    }
}
