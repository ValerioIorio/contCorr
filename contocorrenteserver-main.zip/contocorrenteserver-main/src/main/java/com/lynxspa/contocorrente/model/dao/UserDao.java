package com.lynxspa.contocorrente.model.dao;

import com.lynxspa.contocorrente.model.entities.Bank;
import com.lynxspa.contocorrente.model.entities.BankAccount;
import com.lynxspa.contocorrente.model.entities.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

   @Component
    public class UserDao
    {



        public void update(User user, long oldBankAccountId, BankAccount newBankAccount)
        {
            BankAccount oldBankAccount= getAccount(user, oldBankAccountId);
            oldBankAccount = newBankAccount;
        }
        public void addAccount(User user, String name, double balance, boolean isSavingsAccount) {
            int id = user.getBankAccounts().size();
            BankAccount newAccount = new BankAccount(id, name, balance, isSavingsAccount)	;
            user.getBankAccounts().add(newAccount);
        }
        public void removeAccount(User user, long id ) {
            user.getBankAccounts().remove(getAccount(user, id));
        }
        public BankAccount getAccount(User user, long id) {
            for(BankAccount b: user.getBankAccounts())
            {
                if (b.getId()==id)
                    return b;
            }
            return null;
        }
    }

