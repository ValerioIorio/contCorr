package com.lynxspa.contocorrente;

import com.lynxspa.contocorrente.model.controller.BankController;
import com.lynxspa.contocorrente.model.entities.BankAccount;
import com.lynxspa.contocorrente.model.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RestController;

import java.util.Scanner;

@SpringBootApplication
public class ContocorrenteApplication implements CommandLineRunner  {





	@Autowired
	BankController bankController;


	public static void main(String[] args) {

		SpringApplication.run(ContocorrenteApplication.class, args);

	}


	@Override
	public void run(String... args) throws Exception {

		bankController._loginMenu();

	}
}
