package com.lynxspa.contocorrente.model.services;

import com.lynxspa.contocorrente.model.dao.BankDao;
import com.lynxspa.contocorrente.model.dao.UserDao;
import com.lynxspa.contocorrente.model.entities.Bank;
import com.lynxspa.contocorrente.model.entities.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BankService
{
    @Autowired
    UserDao userDao;
    @Autowired
    BankDao bankDao;



    public boolean createUser( String username, String password) {
        if (username.isBlank()||username==null||password.isBlank()||password==null)
            return false;
        bankDao.createUser(username, password);
        return true;
    }

    public void deleteUser(long userId){
        User user = bankDao.getUser(userId);
        bankDao.deleteUser(user);
    }

    public User login(String username, String password){
        return bankDao.getUser(username, password);
    }

    public boolean logout(User user)
    {
        if (user==null)
            return false;
        return true;
    }
}
