package com.lynxspa.contocorrente.model.entities;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.ArrayList;
import java.util.List;


public class BankAccount {

    private long id;

    private String name;
    private double balance;
    private boolean savingsAccount;

    private List <String> transactions = new ArrayList<>();



    public BankAccount(long id, String name, double balance, boolean savingsAccount)
    {

        this.id=id;
        this.name = name;
        this.balance = balance;
        this.savingsAccount = savingsAccount;
    }


    public List<String> getTransactions() {
        return transactions;
    }

    public void setTransactions(List<String> transactions) {
        this.transactions = transactions;
    }

    public long getId()
    {
        return id;
    }

    public void setId(long id )
    {
        this.id = id;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public double getBalance()
    {
        return balance;
    }

    public void setBalance(double balance)
    {
        this.balance = balance;
    }

    public boolean isSavingsAccount()
    {
        return savingsAccount;
    }

    public void setSavingsAccount(boolean savingsAccount)
    {
        this.savingsAccount = savingsAccount;
    }

    @Override
    public String toString() {
        return "BankAccount{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", balance=" + balance +
                ", savingsAccount=" + savingsAccount +
                '}';
    }
}
