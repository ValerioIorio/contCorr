package com.lynxspa.contocorrente.model.dao;

import com.lynxspa.contocorrente.model.entities.Bank;
import com.lynxspa.contocorrente.model.entities.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class BankDao {

    private List<User> users = new ArrayList<User>();

    public List<User> getUsers() {
        return users;
    }


    public String toString() {
        return users.get(0).getUsername();
    }

    public void createUser(String username, String password) {
       long id =users.size();
       User user = new User(id, username, password);
       users.add(user);
    }

    public void createMockUser() {
        User user = new User(0, "valexavi", "pollo");
        users.add(user);
    }


    public void deleteUser( User user) {
        users.remove(user);
    }
    public User getUser(long userId){
        for(User u: users)
            if(u.getId()==userId)
                return u;
        return null;
    }

    public User getUser(String username, String password){


        for (User u : users)
            if (
                    u.getUsername()==username
                    && u.getPassword()==password
                )
                return u;
        return null;
    }


}
