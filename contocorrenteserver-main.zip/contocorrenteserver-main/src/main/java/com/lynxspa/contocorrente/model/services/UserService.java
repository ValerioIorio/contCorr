package com.lynxspa.contocorrente.model.services;

import com.lynxspa.contocorrente.model.dao.BankDao;
import com.lynxspa.contocorrente.model.dao.UserDao;
import com.lynxspa.contocorrente.model.entities.BankAccount;
import com.lynxspa.contocorrente.model.entities.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    UserDao userDao;
    @Autowired
    BankDao bankDao;

    public BankAccount getBankAccount(long bankAccountId, User user ) {
        BankAccount bankAccount = userDao.getAccount(user, bankAccountId);
        return bankAccount;
    }
    public boolean createNormalAccount(User user, String name) {

        if(name.isBlank()||name==null)
            return false;

        userDao.addAccount(user, name, 0, false);
        return true;
    }

    public boolean createSavingsAccount(User user, String name, double balance) {

        if(name.isBlank()||name==null||balance<=0)
            return false;

        userDao.addAccount(user, name, balance, true);
        return true;
    }
    public void deleteAccount(User user, long bankAccountId) {
        userDao.removeAccount(user, bankAccountId);
    }
    public String showUserSheet(long userId) {
        User user= bankDao.getUser(userId);
        String res = user.getUsername();
        for(BankAccount b: user.getBankAccounts())
        {
            res+= "/n" + b.getId() + " -- " + b.getName();
        }

        return res;
    }




}
