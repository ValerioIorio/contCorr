package com.lynxspa.contocorrente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContocorrenteApplicationTests {

	@Test
	void contextLoads() {
	}

}
